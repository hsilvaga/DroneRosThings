#!/usr/bin/env python

import rospy
from roadmaps_practice.msg import GridInfo, ObPixels
from nav_msgs.msg import OccupancyGrid

def callback(grid_data): #2darray
	print(grid_data.obs)

def subscriber():
	rospy.Subscriber('mapInfo', GridInfo, callback)
	rospy.spin()

if __name__ == '__main__':
	rospy.init_node('bushfire', anonymous=True)

	subscriber()